/**
 * Created by milax on 29/01/15.
 */
"""
Ejercicio 1. Se trata de realizar un programa de gestiÃ³n de correo electronico.
 Un correo tiene un origen (from), un destino (to), un tema (subject), un cuerpo (body) y un tipo (URGENT, WORK, FAMILY).

Dada una lista de correos calculad:

"""

enum types {URGENT, WORK, FAMILY}

class Correo{
    def from
    def to
    def subject
    def body
    def type

    def String toString(){
        'from:'+from
    }

}

def c1 = new Correo(from: 'Pedro', to: 'Juan', subject: 'Classes', body: 'hola', type: types.WORK)
def c2 = new Correo(from: 'Manuel', to: 'Jose', subject: 'Classes', body: 'cretino', type: types.FAMILY)
def c3 = new Correo(from: 'Susana', to: 'Vane', subject: 'Classes', body: 'cretino', type: types.URGENT)
def c4 = new Correo(from: 'Magda', to: 'Laura', subject: 'Classes', body: 'hola', type: types.WORK)

def list = [c1, c2, c3, c4]


//1. Crear una funciÃ³n getMails(kind,lista) que devuelva una lista con todos los mails del tipo pasado por parÃ¡metro.

def getMails = {kind, lista->
    lista.findAll{it.type==kind}
}

println 'Ex1) '+getMails(types.WORK, list)


//2. Parametrizar parcialmente getMails para que retorne los mails de trabajo

def getMailWork = getMails.curry(types.WORK)
println 'Ex2) '+getMailWork(list)



// 3.  Obtener de la lista los correos que contengan la palabra cretino en el body


println 'Ex3) '+list.findAll {it.body=='cretino'}


//4. Obtener de dos formas diferentes la lista de gente con la que nos comunicamos en el mailbox (to)


"""
Primerament havia fet aquest exercici amb recursivitat de dues formes perquè pensava que era el que demanava, no ho he borrat i ho e deixat de les dues maneres!
"""
/*def mailbox
mailbox = {acc, lista->
    lista? mailbox(acc<<(lista[0]).to, lista.tail()):acc
}

println mailbox([], list)


def mailbox2
mailbox2 = { box, lista ->
    if (lista) {
        mailbox2(box, lista.tail())
        box << lista[0].to
    }
    else
        []
}

println mailbox2([], list)
*/



println 'Ex4):'
println list.collect {it.to}
println list.to

//5. Calculad el tamaÃ±o total del mailbox sumando los tamaÃ±os del body de cada mensaje


println 'Ex5) '+list.collect{it.body}.inject {x,y->x+y}.size()





//6. Implementar la funcion filterreduce en groovy con recursividad de pila y acumulativa.
//  Usadla para calcular la suma de los numeros pares de una lista

println 'Ex6:'

def llista = [1,2,3,4,5,6,7,8]
def filterreduce
filterreduce = {op, f, acc, lista->
    if(lista){
        if(f(lista[0]))
            filterreduce(op, f, op(acc, (lista[0])), lista.tail())
        else
            filterreduce(op, f, op(acc, 0), lista.tail())
    }
    else
        acc
}

def filter = {it%2==0}
def suma = {x,y->x+y}
println filterreduce(suma, filter, 0, llista)


def filterreduce2
filterreduce2 = {op, f, acc, lista->

    if(lista){
        filterreduce2(op, f, acc, lista.tail())
        if(f(lista[0]))
            op(acc, lista[0])
        else
            op(acc, 0)
    }
    else
        0
}
println filterreduce2(suma, filter, 0, llista)



// Ejercicio 2. Implementar un Ã¡rbol de ficheros y directorios en Groovy. Un directorio contiene ficheros y directorios.
// Un fichero tiene un nombre y un tamaÃ±o. Un directorio tiene un nombre y una lista de ficheros y directorios.
// a) Queremos una funcion que planarice el arbol a una lista.
// b) AÃ±adir una funcion reduce al arbol que permita aplicarle una funciÃ³n y obtener un resultado. Usadla para
// obtener el fichero mas grande del arbol
// c) AÃ±ade el mÃ©todo toList usando metaprogramming
// d) AÃ±ade el mÃ©todo toList usando Traits.

println 'Ejercicio 2:'

def toList2 = {
    def result = []
    result<<delegate
    children.each{result.addAll(it.toList2())}
    result
}
def toList2File = {
    def result = []
    result<<delegate
    result
}
Directory.metaClass.toList2 = toList2
File.metaClass.toList2 = toList2File


trait Listable{
    def toList3(){
        def result = []
        result<<this
        children.each{result.addAll(it.toList3())}
        result
    }
}

trait ListableFile{
    def toList3(){
        def result = []
        result<<this
        result
    }
}

class Directory implements Listable{
    def name
    def children = []


   def String toString(){
       'name:'+name
   }

    def addChild(child){
        children.add(child)
    }
    def getSize(){
        children*.getSize().sum()
    }

   def toList(){
       def result = []
       result<<this
       children.each{result.addAll(it.toList())}
       result
   }
    def reduce(f, value){
        children.each {value=it.reduce(f, value)}
        value
    }
}

class File implements ListableFile{
    def name
    def size

    def String toString(){
        'name:'+name
    }

    def getSize(){
        size
    }
    def toList(){
        def result = []
        result<<this
        result
    }
    def reduce(f, value){
        value=f(this, value)
        value
    }

}

def root = new Directory(name: 'root')
def home = new Directory(name: 'home')
def ricard = new Directory(name: 'ricard')
def f1 = new File(name: 'f1', size: 1)
def f2 = new File(name: 'f2', size: 1)
def f3 = new File(name: 'f3', size: 2)
def f4 = new File(name: 'f4', size: 1)

root.addChild(home)
home.addChild(ricard)
ricard.addChild(f1)
ricard.addChild(f2)
home.addChild(f3)
root.addChild(f4)


//a
println root.toList()
//println root.getSize()

//b
def f = {x,y->x.size<y.size?y:x}
println root.reduce(f, f1)

//c
println 'Metaprograming:'
println root.toList2()

println 'Traits:'
println root.toList3()











