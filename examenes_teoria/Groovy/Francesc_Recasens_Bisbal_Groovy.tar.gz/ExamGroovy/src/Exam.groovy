"""
Ejercicio 1. Se trata de realizar un programa de gestión de correo electronico.
 Un correo tiene un origen (from), un destino (to), un tema (subject), un cuerpo (body) y un tipo (URGENT, WORK, FAMILY).

Dada una lista de correos calculad:

"""

enum Type{URGENT,WORK,FAMILY}

class Mail{
    def from,to,subject, body
    def Type type

    def String toString(){
        'From: '+from+" To: "+to
    }
}

mail1 = new Mail(from:'URV', to:'Students', subject:'A pagar', type:Type.URGENT, body:'Lore ipsum')
mail2 = new Mail(from:'ETSE', to:'Becaris', subject:'Este mes no cobras', type:Type.WORK, body:'Ipsum lore')
mail3 = new Mail(from:'UOC', to:'URV', subject:'Hola', type:Type.FAMILY, body:'Ola k ase cretino')
mail4 = new Mail(from:'Rajoy', to:'Barcenas', subject:'B', type:Type.URGENT, body:'cretino no volvere a la carcel')
mail5 = new Mail(from:'Google', to:'Students', subject:'We need you', type:Type.WORK, body:'Join us')
mail6 = new Mail(from:'Dad', to:'Son', subject:'Hi', type:Type.FAMILY, body:'Testing my new mail')

mailbox=[mail1,mail2,mail3,mail4,mail5,mail6]







//1. Crear una función getMails(kind,lista) que devuelva una lista con todos los mails del tipo pasado por parámetro.

def getMails={kind,lista->
    lista.findAll{it.type==kind}
}

println '\n\nEjercicio 1'

print '1)\t'
println getMails(Type.URGENT,mailbox)





//2. Parametrizar parcialmente getMails para que retorne los mails de trabajo

def getWorkMail= getMails.curry(Type.WORK)
print '2)\t'
println getWorkMail(mailbox)



// 3.  Obtener de la lista los correos que contengan la palabra cretino en el body

print '3)\t'
println mailbox.findAll{it.body.contains('cretino')}



//4. Obtener de dos formas diferentes la lista de gente con la que nos comunicamos en el mailbox (to)

print '4\t'
println mailbox.to

println '\t'+mailbox.collect{it.to}




//5. Calculad el tamaño total del mailbox sumando los tamaños del body de cada mensaje

print '5)\t'
println mailbox.collect{it.body.length()}.sum()




//6. Implementar la funcion filterreduce en groovy con recursividad de pila y acumulativa.
//  Usadla para calcular la suma de los numeros pares de una lista

def lista1= [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]

def filterreduce(op,f,list,acc){
    if(list){
        if(f(list.first()))
            acc=op(acc,list.first())
        filterreduce(op,f,list.tail(),acc)
    }
    else
        acc
}
print '6)\t'
println filterreduce({x,y->x+y},{it%2==0},lista1,0)


def filterreduce2(op,f,list) {
    if (list.size() == 1)
        f(list.first())? list.first():0
    else{
            if(f(list.first()))
                op(list.first(),filterreduce2(op,f,list.tail()))
            else{
                filterreduce2(op,f,list.tail())
            }
        }
}

println '\t'+filterreduce2({x,y->x+y},{it%2==0},lista1)





// Ejercicio 2. Implementar un árbol de ficheros y directorios en Groovy. Un directorio contiene ficheros y directorios.
// Un fichero tiene un nombre y un tamaño. Un directorio tiene un nombre y una lista de ficheros y directorios.
// a) Queremos una funcion que planarice el arbol a una lista.
// b) Añadir una funcion reduce al arbol que permita aplicarle una función y obtener un resultado. Usadla para
// obtener el fichero mas grande del arbol
// c) Añade el método toList usando metaprogramming
// d) Añade el método toList usando Traits.


trait ListableFile{
    def toListTrait(){
        0
    }
}

trait ListableDirectory{
    def toListTrait(){
        def result=[]
        children.each {
            result.add(it)
            result.addAll(it.toListTrait())
        }
        result
    }
}

class AnElement{
    def name,size
    def String toString(){
        'name: '+name
    }
}

class Directory extends AnElement implements ListableDirectory{
    def AnElement[] children=[]
    def toList(){
        def result=[]
        children.each {
            result.add(it)
            result.addAll(it.toList())
        }
        result
    }

    def reduce(f,value,list){
        list?reduce(f,f(value,list.first()),list.tail()):value
    }
}

class File extends AnElement implements ListableFile{
    def String toString(){
        super.toString()+' Size: '+size
    }

    def toList(){
        0
    }

}
Directory.metaClass.toListMeta(){
    def result=[]
    children.each {
        result.add(it)
        result.addAll(it.toListMeta())
    }
    result
}
File.metaClass.toListMeta(){
    0
}
dir1 = new Directory(name:'/',size:0)
dir2 = new Directory(name:'home',size:0)
dir3 = new Directory(name:'milax',size:0)
file1 = new File(name:'test.groovy', size:4)
file2 = new File(name:'user.txt', size:8)

dir1.children=[dir2]
dir2.children=[file1,dir3]
dir3.children=[file2]

def getMaxSizeFile= { x,y -> Math.max(x.size, y.size)==x.size?x:y}

println '\n\nEjercicio 2'

print 'a)\t'
println dir1.toList()

print 'b)\t'
println dir1.reduce(getMaxSizeFile,dir1,dir1.toList())

print 'c)\t'
println dir1.toListMeta()

print 'd)\t'
println dir1.toListTrait()















