/**
 * Created by milax on 29/01/15.
 * Marc Serret Monserrat
 */

enum Kinda {URGENT,WORK,FAMILY}

class correo {
    def from,to,tema,body
    def Kinda tipus


    def String toString(){
        "form:"+from+" to:"+to+"|"
    }
}

correo1=new correo(from:'pepito1',to: 'menganito1',tema: 'hola1',body: 'hola1',tipus:Kinda.FAMILY)
correo2=new correo(from:'pepito2',to: 'menganito2',tema: 'hola2',body: 'hola2',tipus:Kinda.WORK)
correo3=new correo(from:'pepito3',to: 'menganito1',tema: 'hola3',body: 'hola3 cretino',tipus:Kinda.FAMILY)
correo4=new correo(from:'pepito4',to: 'menganito4',tema: 'hola4',body: 'hola4',tipus:Kinda.URGENT)
correo5=new correo(from:'pepito5',to: 'menganito5',tema: 'hola5',body: 'hola5',tipus:Kinda.WORK)

def Correos=[correo1,correo2,correo3,correo4,correo5]
println("Ejercicio1--------------------------------------------------------------------------------------")
println("1--------------------------------------------------------------------------------------")
def getCorreo = {tipuss,list->
    list.findAll({it.tipus == tipuss })
}

println getCorreo(Kinda.FAMILY, Correos)
println("2--------------------------------------------------------------------------------------")
def getCorreoTrabajo = getCorreo.curry(Kinda.WORK)
println getCorreoTrabajo(Correos)

println("3--------------------------------------------------------------------------------------")
def getCorreoEspecifico = {body1,list->
    //list.findAll({ it.body.each {equals(body1)})// .equals(body1) })
}

println getCorreoEspecifico('cretino',Correos)

println("4--------------------------------------------------------------------------------------")

def listaGente1(list, to1){
    list.findAll({it.to == to1})
}

def listaGente2(list, to1){
    for(elem in list){
        if((elem.to).equals(to1)){
            print elem
        }
    }
}
println listaGente1(Correos,'menganito1')

listaGente2(Correos,'menganito1')
println " "
println "5--------------------------------------------------------------------------------------"


def tamCorreo ={list->
    tam=0;
    for(elem in list){
        tam= tam+elem.body.size()
    }
    println "Tamañao mailbox:"+tam
}

tamCorreo(Correos)

println "6--------------------------------------------------------------------------------------"

pila=[1,2,3,4,5]
def sum ={x,y -> x+y}
//recursividad de pila
def recPila(pila,op){
    if(pila==[]){
       op(0,0)
    }else{
        if(pila.first()%2==0){
            op(recPila(pila.tail(),op),pila.first())
        }else{
            op(recPila(pila.tail(),op),0)
        }


    }
}

//recursividad acumulativa

def recAcum(pila,op,val){
    if(pila==[]){
        val
    }else{
        if(pila.first()%2==0){
            val=op(val,pila.first())
        }
        recAcum(pila.tail(),op,val)

    }
}

println recAcum(pila,sum,0)

println recPila(pila,sum)

println "Ejercicio 2 --------------------------------------------------------------------"

class fichero{
    def nameFi,tamFi
}
class directorio{
    def namDire
    def listaFicheros
    def listaDirectorios

    def listF(){
        if(listaFicheros!=[]){
            this.listaFicheros.collect()
        }

    }
    def listD(){
        if (listaDirectorios!=[]){
            this.listaDirectorios.collect()
            if(this.listaFicheros!=[]){
                println this.listaFicheros
            }
        }

    }
    def toList(){

    }
}

raiz=new directorio(namDire: 'raiz',listaDirectorios: ['dire1','dire2'],listaFicheros: ['fi1'])
dire1=new directorio(namDire: 'dire1',listaDirectorios: [],listaFicheros: ['fi2'])
dire2=new directorio(namDire: 'dire2',listaDirectorios: [],listaFicheros: ['fi3'])

fi1=new fichero(nameFi: 'fi1',tamFi: 5)
fi2=new fichero(nameFi: 'fi2',tamFi: 10)
fi3=new fichero(nameFi: 'fi3',tamFi: 15)

def sistema = [raiz,dire1,dire2,fi1,fi2,fi3]
raiz.listD()


def toList= {->
    println 'toList metaprogramming'
}

directorio.metaClass.toList = toList()

raiz.toList()