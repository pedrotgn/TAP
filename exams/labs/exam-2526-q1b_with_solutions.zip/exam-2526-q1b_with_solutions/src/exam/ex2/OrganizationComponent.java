package exam.ex2;

public interface OrganizationComponent {
    int getEventCount();
}
