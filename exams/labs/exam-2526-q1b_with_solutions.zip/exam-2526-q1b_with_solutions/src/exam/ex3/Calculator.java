package exam.ex3;

public interface Calculator {
    int sum(int a, int b);
}
