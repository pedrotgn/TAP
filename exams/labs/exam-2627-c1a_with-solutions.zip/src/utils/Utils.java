package utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

public class Utils {

    public static List<Query> loadQueries(String filePath) throws IOException {
        List<Query> queries = new LinkedList<>();

        try (FileReader fis = new FileReader(filePath)) {
            BufferedReader dis = new BufferedReader(fis);

            String line = dis.readLine(); // skip header
            while ((line = dis.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }
                // limit -1 keeps a trailing empty field (no interactions)
                String[] fields = line.split(",", -1);
                Query q = new Query(
                        Integer.parseInt(fields[0].trim()),
                        fields[1].trim(),
                        fields[2].trim(),
                        fields.length > 3 ? fields[3].trim() : "");
                queries.add(q);
            }
        }

        return queries;
    }

}