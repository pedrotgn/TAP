package utils;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Query {
    private int userId;
    private String timestamp;
    private String queryText;
    private String interactions;

    public Query(int userId, String timestamp, String queryText, String interactions) {
        this.userId = userId;
        this.timestamp = timestamp;
        this.queryText = queryText;
        this.interactions = interactions;
    }

    public int getUserId() {
        return userId;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public String getQueryText() {
        return queryText;
    }

    public List<String> getInteractions() {
        if (interactions == null || interactions.isEmpty()) {
            return Collections.emptyList();
        }
        return Arrays.asList(interactions.split(";"));
    }

    @Override
    public String toString() {
        return userId + " " + timestamp + " " + queryText + " [" + interactions + "]";
    }
}