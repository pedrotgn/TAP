package ex3;


public class Main {

    public static void main(String[] args) {

        System.out.println("\n---------------- Exercise 3 ----------------");

    }
}
