package ex2;

public class Main {

    public static void main(String[] args) {

        System.out.println("\n---------------- Exercise 2.1 ----------------");


        System.out.println("\n---------------- Exercise 2.2 ----------------");

    }

    // Auxiliar method for printing a Pizza
    private static void printPizza(Pizza p) {
        System.out.println(p.getDescription() + " = " + p.getPrice()+"€");
    }
    
}
