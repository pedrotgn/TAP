package ex2;

public interface Pizza {

    String getDescription();

    double getPrice();
    
}