package ex1Solution;

import java.io.IOException;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import utils.Query;
import static utils.Utils.loadQueries;

public class Main {

    public static void main(String[] args) throws IOException {

        System.out.println("\n---------------- Queries loading ----------------");
        List<Query> queries = loadQueries("queries.csv");
        queries.forEach(System.out::println);

        System.out.println("\n---------------- Exercise 1.1 ----------------");
        queries.sort(Comparator.comparing(Query::getQueryText).reversed());
        queries.forEach(System.out::println);

        System.out.println("\n---------------- Exercise 1.2 ----------------");
        List<Query> diabetesQueries = filterByQuerySubstring(queries, "diabetes");
        diabetesQueries.forEach(System.out::println);

        System.out.println("\n---------------- Exercise 1.3 ----------------");
        List<String> allInteractions = getInteractions(queries);
        System.out.println(allInteractions);

        System.out.println("\n---------------- Exercise 1.4 ----------------");
        Map<Integer, List<Query>> queriesGroupedByUser = groupByUser(queries);
        queriesGroupedByUser.forEach((user, list) -> {
            System.out.println("User " + user + ":");
            list.forEach(q -> System.out.println("  " + q));
        });

        System.out.println("\n---------------- Exercise 1.5 ----------------");
        Optional<Query> firstQueryBy101 = getFirstQueryByUser(queries, 101);
        System.out.println(firstQueryBy101);
        Optional<Query> firstQueryBy999 = getFirstQueryByUser(queries, 999);
        System.out.println(firstQueryBy999); // Optional.empty because there are no queries for this user
        
    }

    // 1.2 Generic filter
    public static List<Query> filter(List<Query> queries, Predicate<Query> condition) {
        return queries.stream()
                .filter(condition)
                .collect(Collectors.toList());
    }

    public static List<Query> filterByQuerySubstring(List<Query> queries, String substring) {
        return filter(queries, q -> q.getQueryText().contains(substring));
    }

    // 1.3 All interactions in a single list
    public static List<String> getInteractions(List<Query> queries) {
        return queries.stream()
                .flatMap(q -> q.getInteractions().stream())
                .collect(Collectors.toList());
    }

    // 1.4 One group per user
    public static Map<Integer, List<Query>> groupByUser(List<Query> queries) {
        return queries.stream()
                .collect(Collectors.groupingBy(Query::getUserId));
    }

    // 1.5 Oldest query of a user (timestamps compared as strings)
    public static Optional<Query> getFirstQueryByUser(List<Query> queries, Integer userID) {
        return queries.stream()
                .filter(q -> userID != null && q.getUserId() == userID)
                .min(Comparator.comparing(Query::getTimestamp));
    }

}