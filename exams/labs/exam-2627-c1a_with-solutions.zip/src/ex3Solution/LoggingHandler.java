package ex3Solution;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.Arrays;

public class LoggingHandler implements InvocationHandler {

    private final Object target;

    private LoggingHandler(Object target) {
        this.target = target;
    }

    // Wraps any object that implements at least one interface
    @SuppressWarnings("unchecked")
    public static <T> T newInstance(T target) {
        Class<?> targetClass = target.getClass();
        return (T) Proxy.newProxyInstance(
                targetClass.getClassLoader(),
                targetClass.getInterfaces(),
                new LoggingHandler(target));
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        System.out.println("Calling " + method.getName() + " with arguments " + Arrays.toString(args));
        try {
            Object result = method.invoke(target, args);
            System.out.println(method.getName() + " returned " + result);
            return result;
        } catch (InvocationTargetException ite) {
            Throwable cause = ite.getTargetException();
            System.out.println(method.getName() + " threw " + cause);
            throw cause; // the caller still sees the original exception
        }
        catch (UndeclaredThrowableException ute) {
            Throwable cause = ute.getUndeclaredThrowable();
            System.out.println(method.getName() + " threw " + cause);
            throw cause; // the caller still sees the original exception
        }        
    }
}