package ex3Solution;

public class Main {

    public static void main(String[] args) {    

        System.out.println("\n---------------- Exercise 3 ----------------");
        Calculator calculator = LoggingHandler.newInstance(new BasicCalculator());

        calculator.add(2, 3);
        calculator.subtract(10, 4);
        calculator.multiply(6, 7);
        calculator.divide(20, 5);

        try {
            calculator.divide(1, 0);
        } catch (ArithmeticException e) {
            System.out.println("Caller caught: " + e);
        }
    
    }

}
