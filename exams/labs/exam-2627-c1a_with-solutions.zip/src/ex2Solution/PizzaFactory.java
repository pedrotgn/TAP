package ex2Solution;

public abstract class PizzaFactory {

    public abstract Pizza createMargherita();

    public abstract Pizza createPepperoni();
    
}
