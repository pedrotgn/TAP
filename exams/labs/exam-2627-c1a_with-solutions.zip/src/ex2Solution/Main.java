package ex2Solution;

public class Main {

    public static void main(String[] args) {

        System.out.println("\n---------------- Exercise 2.1 ----------------");
        PizzaFactory napoli = new NapoliFactory();
        printPizza(napoli.createMargherita());
        printPizza(napoli.createPepperoni());
        PizzaFactory newYork = new NewYorkFactory();        
        printPizza(newYork.createMargherita());
        printPizza(newYork.createPepperoni());

        System.out.println("\n---------------- Exercise 2.2 ----------------");
        Pizza p1 = new Olives(newYork.createMargherita());
        printPizza(p1);

        Pizza p2 = new ExtraCheese(new Olives(napoli.createMargherita()));
        printPizza(p2);

        Pizza p3 = new ExtraCheese(new ExtraCheese(newYork.createPepperoni()));
        printPizza(p3);
    }

    // Auxiliar method for printing a Pizza
    private static void printPizza(Pizza p) {
        System.out.println(p.getDescription() + " = " + p.getPrice()+"€");
    }
}