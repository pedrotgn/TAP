package ex2Solution;

public class ExtraCheese implements Pizza {
 
    private final Pizza pizza;
 
    public ExtraCheese(Pizza pizza) {
        this.pizza = pizza;
    }
 
    @Override
    public String getDescription() {
        return pizza.getDescription() + " + Extra Cheese";
    }
 
    @Override
    public double getPrice() {
        return pizza.getPrice() + 1.25;
    }
}

