package ex2Solution;

public class NeapolitanPepperoni implements Pizza {
 
    @Override
    public String getDescription() {
        return "Neapolitan Pepperoni";
    }
 
    @Override
    public double getPrice() {
        return 8.50;
    }
}

