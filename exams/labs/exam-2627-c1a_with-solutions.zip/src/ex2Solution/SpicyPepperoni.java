package ex2Solution;

public class SpicyPepperoni implements Pizza {
 
    @Override
    public String getDescription() {
        return "Spicy Pepperoni";
    }
 
    @Override
    public double getPrice() {
        return 17.00;
    }
}

