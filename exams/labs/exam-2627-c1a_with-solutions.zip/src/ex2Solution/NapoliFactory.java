package ex2Solution;

public class NapoliFactory extends PizzaFactory {
 
    @Override
    public Pizza createMargherita() {
        return new NeapolitanMargherita();
    }
 
    @Override
    public Pizza createPepperoni() {
        return new NeapolitanPepperoni();
    }
}
 

