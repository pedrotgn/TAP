package ex2Solution;

public class NeapolitanMargherita implements Pizza {
 
    @Override
    public String getDescription() {
        return "Neapolitan Margherita";
    }
 
    @Override
    public double getPrice() {
        return 6.50;
    }
}

