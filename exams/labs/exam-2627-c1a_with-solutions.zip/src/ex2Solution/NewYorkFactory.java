package ex2Solution;

public class NewYorkFactory extends PizzaFactory {
 
    @Override
    public Pizza createMargherita() {
        return new ThinCrustMargherita();
    }
 
    @Override
    public Pizza createPepperoni() {
        return new SpicyPepperoni();
    }
}

