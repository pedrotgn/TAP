package ex2Solution;

public interface Pizza {

    String getDescription();

    double getPrice();
    
}