package ex2Solution;

public class Olives implements Pizza {
 
    private final Pizza pizza;
 
    public Olives(Pizza pizza) {
        this.pizza = pizza;
    }
 
    @Override
    public String getDescription() {
        return pizza.getDescription() + " + Olives";
    }
 
    @Override
    public double getPrice() {
        return pizza.getPrice() + 0.75;
    }
}

