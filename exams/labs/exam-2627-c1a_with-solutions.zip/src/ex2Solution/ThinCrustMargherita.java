package ex2Solution;

public class ThinCrustMargherita implements Pizza {
 
    @Override
    public String getDescription() {
        return "Thin Crust Margherita";
    }
 
    @Override
    public double getPrice() {
        return 15.50;
    }
}

