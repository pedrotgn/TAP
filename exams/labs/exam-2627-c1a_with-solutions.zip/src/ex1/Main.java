package ex1;

import java.io.IOException;
import java.util.*;

import utils.Query;
import static utils.Utils.loadQueries;

public class Main {

    public static void main(String[] args) throws IOException {

        System.out.println("\n---------------- Queries loading ----------------");
        List<Query> queries = loadQueries("queries.csv");
        queries.forEach(System.out::println);

        System.out.println("\n---------------- Exercise 1.1 ----------------");


        System.out.println("\n---------------- Exercise 1.2 ----------------");


        System.out.println("\n---------------- Exercise 1.3 ----------------");
        

        System.out.println("\n---------------- Exercise 1.4 ----------------");


        System.out.println("\n---------------- Exercise 1.5 ----------------");

        
    }

}
