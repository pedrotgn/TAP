# TAP Java Exam 1st Call (23/10/2026)
This `README` provides the assignment description for the exam, while the `src` folder and its subfolders define the project’s file structure. Additional files required for some exercises may also be included in the `src` folder.

* **Exercises**:
  The exam includes three exercises, each consisting of multiple tasks. 
  The code for each exercise will be contained at `src/ex[Number]`. The folder should include, at least, a `Main` file that demonstrates the completion of each task.

* **Evaluation**:
  Each exercise will be graded independently.
  Whenever possible, each task within an exercise will be evaluated separately.

* **Submission instructions**:
  To submit your work, compress the entire folder into a ZIP file named using the following convention:
  `[Surname(s)]_[Name].zip` (e.g., `JSimpson_Homer.zip`).  
  > **Note**: Do not include the TAP repository itself in your submission. If you need to use any code from that repository, copy only the necessary files into the appropriate folder.

---

## Exercise 1 — Functional Java `(src/ex1)`

### Dataset
This exercise employs a *synthetic* dataset of user searches on [PatientsLikeMe](https://www.patientslikeme.com/) made by European users, contained in the `queries.csv` file (25 queries, the first line is a header). Run your program from the project root folder so that the relative path `issues.csv` is found.

The data is stored in CSV format, where each row corresponds to a query with the following fields:
| Field                 | Description                                      |
| --------------------- |--------------------------------------------------|
| **User ID**           | Unique identifier of the user (integer)          |
| **Timestamp**         | Time of the search in `yyyy-MM-dd HH:mm:ss` format (string, not date)          |
| **Query text**        | Text of the query (string)          |
| **Interactions**      | List of interaction names (potentially empty), separated by `;` in the CSV (e.g., `scroll;click`)          |

The `Query` class (including the `getInteractions` method for getting the list of interactions as a  `List<String>`), along with the method responsible for loading the dataset (i.e., `loadDataset`), are provided.

Unless stated otherwise, methods must **not** modify the list they receive, and the returned lists must keep the order of the input list.

### Tasks
1. [10%] Sort the list of queries by `Query text` (*descending alphabetical order*). Queries with the same query text may appear in any relative order. You may sort the loaded list in place or produce a new sorted list; both are accepted.
2. [20%] Implement a `filter` method using a `Predicate<Query>` and streams:
    ```java
    List<Query> filter(List<Query> queries, Predicate<Query> condition);
    ```
    Using this method, implement a new one named `filterByQuerySubstring` that returns the queries including a particular string.
    ```java
    List<Query> filterByQuerySubstring(List<Query> queries, String substring);
    ```
3. [20%] Implement a `getInteractions` method using streams that obtains all interactions from a list of queries into a single list of strings:
  ```java
    List<String> getInteractions(List<Query> queries);
  ```
4. [20%] Implement a method to *group* queries made by the same user (**one group per user**) using streams. The order of the keys of the map is not relevant.
    ```java
    Map<Integer, List<Query>> groupByUser(List<Query> queries);
    ```
5. [30%] Implement a method that provides the **first `Query` (the one with the oldest `Timestamp` value) of an specified user** using streams. Because of the `Timestamp` format, comparing the strings alphabetically gives the chronological order; do not convert them into dates. If the user has no queries, return `Optional.empty()` (do not return `null` and do not throw an exception).
    ```java
    Optional<Query> getFirstQueryByUser(List<Query> queries, Integer userID);
    ```

**Topics**: PREDICATE, FUNCTION, STREAMS, COLLECTORS

---

## Exercise 2 — Design Patterns `(src/ex2)`

### Tasks
We will build a pizza ordering system in which pizzas come from region-specific factories and can be dynamically extended with toppings. As a starting point, we provide the `Pizza` interface (with methods to get the description and the price) and an empty abstract `PizzaFactory` class.

1. [70%] Implement the Factory pattern so that the client never instantiates concrete pizzas. Define one typed creation method per product on the abstract `PizzaFactory`. Then develop two concrete factories, each producing its own recipes:
  - `NapoliFactory`: `NeapolitanMargherita` (6.50), `NeapolitanPepperoni` (8.50).
  - `NewYorkFactory`: `ThinCrustMargherita` (15.50), `SpicyPepperoni` (17.00).

2. [30%] Implement the Decorator pattern on top, so that toppings can be added to any pizza from any factory without modifying existing classes. Develop the following decorators:
  - `Olives`: +0.75.
  - `ExtraCheese`: +1.25.
  Decorators append its name to the description and its price to the total.

**Topics**: FACTORY, DECORATOR

---

## Exercise 3 — Reflection `(src/ex3)`

### Tasks

We will build a reusable logging layer with **Java's Dynamic Proxy** that wraps any interface without modifying its implementations. As a starting point, we provide the `Calculator` interface (with methods such as `add`, `subtract`, `multiply`, and `divide`) and a `BasicCalculator` class that implements it.

1. [100%] Create a `LoggingHandler` class implementing `InvocationHandler`. Every intercepted call must be surrounded by prints showing:
   - Before the call, the method name and the arguments received.
   - After the call, the value returned.
   - If the real method throws an exception, the caller must receive **that same exception** (e.g., `ArithmeticException`), not an `InvocationTargetException` or an `UndeclaredThrowableException`.

In `Main`, create the proxy with `Proxy.newProxyInstance` and demonstrate valid calls and an exception thrown by the real object reaching the caller.

**Topics**: REFLECTION → DYNAMIC PROXY
