package exam.ex2;

public interface Vehicle {
    void accept(VehicleVisitor visitor);
}
