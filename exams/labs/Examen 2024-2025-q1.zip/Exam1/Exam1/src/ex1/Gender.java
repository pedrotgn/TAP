package ex1;

/**
 * @author MikeW
 */
public enum Gender { MALE, FEMALE }
