package ex1;

public enum Query {ALL, MAX}
