# TAP Java Exam 1st Call (23/10/2026)
This `README` provides the assignment description for the exam, while the `src` folder and its subfolders define the project’s file structure. Additional files required for some exercises may also be included in the `src` folder.

* **Exercises**:
  The exam includes three exercises, each consisting of multiple tasks. 
  The code for each exercise will be contained at `src/ex[Number]`. The folder should include, at least, a `Main` file that demonstrates the completion of each task.

* **Evaluation**:
  Each exercise will be graded independently.
  Whenever possible, each task within an exercise will be evaluated separately.

* **Submission instructions**:
  To submit your work, compress the entire folder into a ZIP file named using the following convention:
  `[Surname(s)]_[Name].zip` (e.g., `JSimpson_Homer.zip`).  
  > **Note**: Do not include the TAP repository itself in your submission. If you need to use any code from that repository, copy only the necessary files into the appropriate folder.

---

## Exercise 1 — Functional Java `(src/ex1)`

### Dataset
This exercise employs a *synthetic* dataset of issues reported in the issue tracker of a software company, contained in the `issues.csv` file (300 issues, the first line is a header). Run your program from the project root folder so that the relative path `issues.csv` is found.

The data is stored in CSV format, where each row corresponds to an issue with the following fields:
| Field         | Description                                                                         |
| ------------- |-------------------------------------------------------------------------------------|
| **Issue ID**  | Unique identifier of the issue (integer)                                            |
| **Reporter**  | Username of the person who reported the issue (string)                              |
| **Created**   | Creation time in `yyyy-MM-dd HH:mm:ss` format (string, not date). No two issues share the same value |
| **Title**     | Short description of the issue (string)                                             |
| **Component** | Part of the product affected (string, e.g., `backend`)                              |
| **Labels**    | One or more labels separated by `;` in the CSV (e.g., `bug;security`)               |

The `Issue` class, along with the method responsible for loading the dataset (i.e., `loadDataset`), are provided. `getLabels()` already returns the labels of an issue as a `List<String>`.

Unless stated otherwise, methods must **not** modify the list they receive, and the returned lists must keep the order of the input list.

### Tasks
1. [10%] Sort the list of issues by `Component` (*ascending alphabetical order*). Issues with the same component may appear in any relative order. You may sort the loaded list in place or produce a new sorted list; both are accepted.
2. [20%] Implement a `getDistinctLabels` method using streams to obtain all the labels used in the dataset, **each label exactly once**. The order of the labels in the returned list is not relevant. You must use `flatMap`.
    ```java
    List<String> getDistinctLabels(List<Issue> issues);
    ```
3. [20%] Implement a `filter` method using a `Predicate<Issue>` and streams:
    ```java
    List<Issue> filter(List<Issue> issues, Predicate<Issue> condition);
    ```
    Using this method, implement a new one named `filterByLabel` that returns the issues whose labels include the given label. The comparison is exact and case-sensitive (`"security"` matches only the label `security`).
    ```java
    List<Issue> filterByLabel(List<Issue> issues, String label);
    ```
4. [20%] Implement a method to *group* the issues by `Component` (**one group per component**) using streams. The order of the keys of the map is not relevant.
    ```java
    Map<String, List<Issue>> groupByComponent(List<Issue> issues);
    ```
5. [30%] Implement a method that provides the **latest `Issue` (the one with the most recent `Created` value) reported by a specified user** using streams. Because of the `Created` format, comparing the strings alphabetically gives the chronological order; do not convert them into dates. If the user has not reported any issue, return `Optional.empty()` (do not return `null` and do not throw an exception).
    ```java
    Optional<Issue> getLatestIssueByReporter(List<Issue> issues, String reporter);
    ```

**Topics**: PREDICATE, FUNCTION, STREAMS, FLATMAP, COLLECTORS

---

## Exercise 2 — Design Patterns `(src/ex2)`

### Tasks
We will build a continuous integration system in which every build pipeline follows the same sequence of steps, although each build tool performs some of those steps differently. Two legacy build tools that we cannot modify must also be integrated. As a starting point, we provide an empty abstract `BuildPipeline` class and the third-party `LegacyMakeTool` and `LegacyAntTool` classes (**do not modify them**).

Every step prints exactly one line with the format `[<step>] <command> (<seconds> s)`, e.g., `[compile] mvn compile (40 s)`, and returns its duration in seconds (`int`).

1. [70%] Implement the **Template Method** pattern in `BuildPipeline`:
   - A template method `public final int run()` that executes the steps in this fixed order: `checkout`, `compile`, `test` and, only if the hook `shouldPackage()` returns `true`, `packageArtifact`. When packaging is not performed, it prints `[package] skipped` instead. Finally, it prints `Total: <seconds> s` and returns the sum of the durations of the executed steps.
   - `checkout()` is common to all pipelines and is implemented only once, in `BuildPipeline`: command `git clone`, 10 s.
   - `compile()`, `test()` and `packageArtifact()` are abstract.
   - The hook `shouldPackage()` returns `true` by default.

   Then develop three concrete pipelines (subclasses must not override `run()`):
   | Class            | `compile`              | `test`              | `packageArtifact`      | Total  |
   |------------------|------------------------|---------------------|------------------------|--------|
   | `MavenPipeline`  | `mvn compile` (40)     | `mvn test` (60)     | `mvn package` (20)     | 130 s  |
   | `GradlePipeline` | `gradle classes` (30)  | `gradle test` (45)  | `gradle jar` (15)      | 100 s  |
   | `NpmPipeline`    | `npm run build` (25)   | `npm test` (35)     | *not performed*: `shouldPackage()` returns `false` | 70 s |

2. [30%] Implement the **Adapter** pattern so that two legacy build tools, `LegacyMakeTool` and `LegacyAntTool`, can be used wherever a `BuildPipeline` is expected, without modifying any of them. Each adapter receives the legacy tool in its constructor and delegates every step to it. The durations must be obtained from the legacy tool (do not write them as constants).
   - `MakePipelineAdapter`: `make(target)` runs a target and **returns** its duration in seconds. Must return 150 s.
     | Step              | Target  | Command printed |
     |-------------------|---------|-----------------|
     | `compile`         | `all`   | `make all`      |
     | `test`            | `check` | `make check`    |
     | `packageArtifact` | `dist`  | `make dist`     |
   - `AntPipelineAdapter`: `execute(task)` runs a task but **returns nothing**; its duration, in **milliseconds**, must be obtained afterwards with `getLastDurationMillis()` and converted to seconds (all durations are whole seconds). Must return 112 s.
     | Step              | Task      | Command printed |
     |-------------------|-----------|-----------------|
     | `compile`         | `compile` | `ant compile`   |
     | `test`            | `junit`   | `ant junit`     |
     | `packageArtifact` | `jar`     | `ant jar`       |

Demonstrate in `Main` that all five pipelines can be stored in the same `List<BuildPipeline>` and run.

**Topics**: TEMPLATE METHOD, ADAPTER

---

## Exercise 3 — Reflection `(src/ex3)`

### Tasks

We will build a reusable validation layer with **Java's Dynamic Proxy** that rejects `null` arguments on any interface without modifying its implementations. As a starting point, we provide the `UserDirectory` interface (with methods `register`, `getEmail`, `remove` and `count`) and an `InMemoryUserDirectory` class that implements it (which, on its own, accepts `null` values).

1. [100%] Create a `NullArgumentCheckHandler` class implementing `InvocationHandler`. It receives the real object in its constructor and, for every intercepted call:
   - Before the call, if any argument is `null`, it throws an `IllegalArgumentException` with the message `Argument <i> of <methodName> is null`, where `<i>` is the zero-based position of the first `null` argument (e.g., `Argument 1 of register is null`). In this case the real method must **not** be executed.
   - Methods without parameters (e.g., `count()`) must work normally.
   - Otherwise, it invokes the real method and returns its result unchanged.
   - If the real method throws an exception, the client must receive **that same exception** (e.g., the `IllegalStateException` of a duplicated `register`), not an `InvocationTargetException` or an `UndeclaredThrowableException`.

   In `Main`, create the proxy with `Proxy.newProxyInstance` and demonstrate: valid calls, calls with a `null` argument (catch the exception and print its message), and an exception thrown by the real object reaching the client.

**Topics**: REFLECTION → DYNAMIC PROXY
