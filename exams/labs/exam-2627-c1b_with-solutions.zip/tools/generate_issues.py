"""Generates issues.csv (synthetic issue-tracker export) with a fixed seed.

Usage: python3 generate_issues.py [output_path]
"""
import random
import sys
from datetime import datetime, timedelta

SEED = 2026
N_ROWS = 300

REPORTERS = ["alice", "bob", "carla", "dmitri", "elena", "farid", "gina", "hugo",
             "ines", "jonas", "kenji", "laura", "marta", "nadia", "oscar",
             "pablo", "quinn", "rosa", "sven", "tomas"]
COMPONENTS = ["auth", "backend", "database", "frontend", "mobile", "payments"]
LABELS = ["bug", "enhancement", "performance", "security", "documentation",
          "regression", "accessibility", "good-first-issue", "duplicate", "wontfix"]
PROBLEMS = ["Crash", "Timeout", "Wrong output", "Memory leak", "Slow response",
            "Missing translation", "Broken layout", "Null pointer", "Deadlock",
            "Unexpected logout"]
ACTIONS = ["when saving", "after updating", "while loading", "on deleting",
           "during export of", "when searching", "on login with"]
OBJECTS = ["user profile", "invoice list", "shopping cart", "settings page",
           "audit log", "order history", "dashboard", "password reset form",
           "notification panel", "report"]


def main(path):
    rnd = random.Random(SEED)
    start = datetime(2026, 1, 1)
    span = int((datetime(2026, 9, 30) - start).total_seconds())
    # Unique timestamps (no ties in "latest" searches)
    seconds = sorted(rnd.sample(range(span), N_ROWS))
    rows = []
    for i, s in enumerate(seconds):
        created = (start + timedelta(seconds=s)).strftime("%Y-%m-%d %H:%M:%S")
        title = f"{rnd.choice(PROBLEMS)} {rnd.choice(ACTIONS)} {rnd.choice(OBJECTS)}"
        labels = rnd.sample(LABELS, rnd.choice([1, 1, 2, 2, 2, 3]))
        rows.append([str(1001 + i), rnd.choice(REPORTERS), created, title,
                     rnd.choice(COMPONENTS), ";".join(labels)])
    # The export is not chronologically ordered
    rnd.shuffle(rows)
    with open(path, "w", newline="\n") as f:
        f.write("IssueId,Reporter,Created,Title,Component,Labels\n")
        for r in rows:
            f.write(",".join(r) + "\n")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "issues.csv")
