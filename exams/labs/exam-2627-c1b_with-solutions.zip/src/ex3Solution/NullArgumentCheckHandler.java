package ex3Solution;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class NullArgumentCheckHandler implements InvocationHandler {

    private final Object target;

    public NullArgumentCheckHandler(Object target) {
        this.target = target;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        // args is null for methods without parameters
        if (args != null) {
            for (int i = 0; i < args.length; i++) {
                if (args[i] == null) {
                    throw new IllegalArgumentException("Argument " + i + " of " + method.getName() + " is null");
                }
            }
        }
        try {
            return method.invoke(target, args);
        } catch (InvocationTargetException e) {
            throw e.getCause(); // the original exception of the real object
        }
    }
}
