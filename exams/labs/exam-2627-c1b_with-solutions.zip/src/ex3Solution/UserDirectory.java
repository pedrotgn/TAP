package ex3Solution;

public interface UserDirectory {

    /** Registers a new user. @throws IllegalStateException if the username already exists */
    void register(String username, String email);

    /** @throws java.util.NoSuchElementException if the username is not registered */
    String getEmail(String username);

    /** @return true if the user existed and was removed */
    boolean remove(String username);

    /** @return number of registered users */
    int count();
}
