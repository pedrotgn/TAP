package ex3Solution;

import java.lang.reflect.Proxy;

/*
 * Expected output (key lines):
 *   count = 2, ana's email, then
 *   Rejected: Argument 1 of register is null
 *   Rejected: Argument 0 of getEmail is null
 *   Real object: IllegalStateException - User ana already exists
 *   Real object: NoSuchElementException - User zoe not found
 *   final count = 2  (the rejected calls never reached the real object)
 *
 * Grading notes:
 *  - Common mistake 1: not checking args == null -> NullPointerException on count().
 *  - Common mistake 2: not unwrapping InvocationTargetException -> the client receives an
 *    UndeclaredThrowableException instead of IllegalStateException.
 *  - Creating the proxy with real.getClass().getInterfaces() or a generic helper is also valid.
 */
public class Main {

    public static void main(String[] args) {

        // Without proxy: null values are silently stored
        UserDirectory plain = new InMemoryUserDirectory();
        plain.register("ghost", null);
        System.out.println("Plain directory count: " + plain.count());

        UserDirectory real = new InMemoryUserDirectory();
        UserDirectory users = (UserDirectory) Proxy.newProxyInstance(
                UserDirectory.class.getClassLoader(),
                new Class<?>[]{UserDirectory.class},
                new NullArgumentCheckHandler(real));

        System.out.println("\n--- Valid calls");
        users.register("ana", "ana@urv.cat");
        users.register("joan", "joan@urv.cat");
        System.out.println("count = " + users.count());               // method without arguments
        System.out.println("ana -> " + users.getEmail("ana"));
        System.out.println("remove joan? " + users.remove("joan"));
        users.register("joan", "joan@urv.cat");

        System.out.println("\n--- Null arguments");
        try {
            users.register("eva", null);
        } catch (IllegalArgumentException e) {
            System.out.println("Rejected: " + e.getMessage());
        }
        try {
            users.getEmail(null);
        } catch (IllegalArgumentException e) {
            System.out.println("Rejected: " + e.getMessage());
        }

        System.out.println("\n--- Exceptions of the real object");
        try {
            users.register("ana", "other@urv.cat");
        } catch (RuntimeException e) {
            System.out.println("Real object: " + e.getClass().getSimpleName() + " - " + e.getMessage());
        }
        try {
            users.getEmail("zoe");
        } catch (RuntimeException e) {
            System.out.println("Real object: " + e.getClass().getSimpleName() + " - " + e.getMessage());
        }

        System.out.println("\nfinal count = " + users.count());
    }
}
