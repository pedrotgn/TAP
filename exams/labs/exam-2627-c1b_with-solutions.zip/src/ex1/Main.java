package ex1;

import java.io.IOException;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.*;

public class Main {

    // TODO 1.2: List<String> getDistinctLabels(List<Issue> issues)

    // TODO 1.3: List<Issue> filter(List<Issue> issues, Predicate<Issue> condition)
    //           List<Issue> filterByLabel(List<Issue> issues, String label)

    // TODO 1.4: Map<String, List<Issue>> groupByComponent(List<Issue> issues)

    // TODO 1.5: Optional<Issue> getLatestIssueByReporter(List<Issue> issues, String reporter)

    public static void main(String[] args) throws IOException {

        System.out.println("\n---------------- Dataset loading ----------------");
        List<Issue> issues = Issue.loadDataset("issues.csv");
        System.out.println(issues.size() + " issues loaded");

        System.out.println("\n---------------- Exercise 1.1 ----------------");
        // TODO: sort by Component (ascending) and print the result

        System.out.println("\n---------------- Exercise 1.2 ----------------");
        // TODO: print the distinct labels

        System.out.println("\n---------------- Exercise 1.3 ----------------");
        // TODO: print the issues labelled "security"

        System.out.println("\n---------------- Exercise 1.4 ----------------");
        // TODO: print the number of issues of each component

        System.out.println("\n---------------- Exercise 1.5 ----------------");
        // TODO: print the latest issue of "alice" and the result for a reporter with no issues (e.g., "zoe")
    }
}
