package ex3;

public class Main {

    public static void main(String[] args) {

        // Without proxy: null values are silently stored
        UserDirectory plain = new InMemoryUserDirectory();
        plain.register("ghost", null);
        System.out.println("Plain directory count: " + plain.count());

        // TODO: create a NullArgumentCheckHandler and a dynamic proxy of UserDirectory, then show:
        //  1. valid calls (register, getEmail, count)
        //  2. a call with a null argument (catch the exception and print its message)
        //  3. an exception thrown by the real object (e.g., duplicated register) reaching the client unchanged
    }
}
