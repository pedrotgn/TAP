package ex3;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

public class InMemoryUserDirectory implements UserDirectory {

    private final Map<String, String> emails = new HashMap<>();

    @Override
    public void register(String username, String email) {
        if (emails.containsKey(username)) {
            throw new IllegalStateException("User " + username + " already exists");
        }
        emails.put(username, email);
    }

    @Override
    public String getEmail(String username) {
        String email = emails.get(username);
        if (email == null) {
            throw new NoSuchElementException("User " + username + " not found");
        }
        return email;
    }

    @Override
    public boolean remove(String username) {
        return emails.remove(username) != null;
    }

    @Override
    public int count() {
        return emails.size();
    }
}
