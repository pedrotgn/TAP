package ex2Solution;

/**
 * Template Method: run() fixes the order of the steps; subclasses fill them in.
 */
public abstract class BuildPipeline {

    // Template method: final so that subclasses cannot change the algorithm
    public final int run() {
        int total = checkout();
        total += compile();
        total += test();
        if (shouldPackage()) {
            total += packageArtifact();
        } else {
            System.out.println("[package] skipped");
        }
        System.out.println("Total: " + total + " s");
        return total;
    }

    // Common step, shared by all pipelines
    protected int checkout() {
        return step("checkout", "git clone", 10);
    }

    protected abstract int compile();
    protected abstract int test();
    protected abstract int packageArtifact();

    // Hook with default behaviour
    protected boolean shouldPackage() {
        return true;
    }

    // Helper (optional) to print a step in the required format
    protected int step(String name, String command, int seconds) {
        System.out.println("[" + name + "] " + command + " (" + seconds + " s)");
        return seconds;
    }
}
