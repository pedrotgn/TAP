package ex2Solution;

public class NpmPipeline extends BuildPipeline {
    @Override protected int compile()         { return step("compile", "npm run build", 25); }
    @Override protected int test()            { return step("test", "npm test", 35); }
    @Override protected int packageArtifact() { return 0; } // never called: packaging is skipped

    @Override
    protected boolean shouldPackage() {
        return false;
    }
}
