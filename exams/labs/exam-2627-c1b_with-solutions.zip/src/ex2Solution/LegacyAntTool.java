package ex2Solution;

/**
 * Third-party class shipped as a binary library. DO NOT MODIFY THIS CLASS.
 * It is not a BuildPipeline and its API does not match ours: running a task
 * returns nothing and the duration (in MILLISECONDS) must be queried afterwards.
 */
public class LegacyAntTool {

    private long lastDurationMillis = 0;

    /**
     * Executes an Ant task.
     *
     * @param task one of "compile", "junit" or "jar"
     * @throws IllegalArgumentException for any other task
     */
    public void execute(String task) {
        switch (task) {
            case "compile": lastDurationMillis = 35_000; break;
            case "junit":   lastDurationMillis = 55_000; break;
            case "jar":     lastDurationMillis = 12_000; break;
            default: throw new IllegalArgumentException("Target \"" + task + "\" does not exist in the project");
        }
    }

    /** @return duration in milliseconds of the last executed task (0 if none was executed) */
    public long getLastDurationMillis() {
        return lastDurationMillis;
    }
}
