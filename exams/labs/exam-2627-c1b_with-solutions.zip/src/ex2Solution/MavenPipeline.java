package ex2Solution;

public class MavenPipeline extends BuildPipeline {
    @Override protected int compile()         { return step("compile", "mvn compile", 40); }
    @Override protected int test()            { return step("test", "mvn test", 60); }
    @Override protected int packageArtifact() { return step("package", "mvn package", 20); }
}
