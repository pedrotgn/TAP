package ex2Solution;

/**
 * Object Adapter for LegacyAntTool. Unlike LegacyMakeTool, the adaptee does not return the
 * duration: it has to be queried after each task and converted from milliseconds to seconds.
 */
public class AntPipelineAdapter extends BuildPipeline {

    private final LegacyAntTool ant;

    public AntPipelineAdapter(LegacyAntTool ant) {
        this.ant = ant;
    }

    private int runTask(String step, String task) {
        ant.execute(task);
        int seconds = (int) (ant.getLastDurationMillis() / 1000);
        return step(step, "ant " + task, seconds);
    }

    @Override protected int compile()         { return runTask("compile", "compile"); }
    @Override protected int test()            { return runTask("test", "junit"); }
    @Override protected int packageArtifact() { return runTask("package", "jar"); }
}
