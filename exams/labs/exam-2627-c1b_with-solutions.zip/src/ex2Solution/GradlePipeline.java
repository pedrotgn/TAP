package ex2Solution;

public class GradlePipeline extends BuildPipeline {
    @Override protected int compile()         { return step("compile", "gradle classes", 30); }
    @Override protected int test()            { return step("test", "gradle test", 45); }
    @Override protected int packageArtifact() { return step("package", "gradle jar", 15); }
}
