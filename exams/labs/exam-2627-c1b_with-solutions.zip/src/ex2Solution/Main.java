package ex2Solution;

import java.util.List;

/*
 * Expected totals: Maven 130 s, Gradle 100 s, Npm 70 s (package skipped), Make (adapter) 150 s, Ant (adapter) 112 s.
 *
 * Grading notes (also valid):
 *  - Printing directly in each step instead of using the optional step() helper.
 *  - NpmPipeline.packageArtifact() returning anything (it is never called) or throwing
 *    UnsupportedOperationException.
 *  - Steps declared public instead of protected (but run() MUST be final and not overridden).
 *  - In AntPipelineAdapter a private helper is optional; integer division by 1000 is exact
 *    for every task (35000, 55000, 12000 ms). Hardcoding 35/55/12 is NOT valid.
 *  - Class Adapter is not possible here (BuildPipeline is a class and Java has no multiple
 *    inheritance), so the expected solution is an Object Adapter (composition).
 */
public class Main {

    public static void main(String[] args) {

        System.out.println("\n---------------- Exercise 2.1 ----------------");
        List<BuildPipeline> pipelines = List.of(new MavenPipeline(), new GradlePipeline(), new NpmPipeline());
        for (BuildPipeline p : pipelines) {
            System.out.println("== " + p.getClass().getSimpleName());
            p.run();
        }

        System.out.println("\n---------------- Exercise 2.2 ----------------");
        List<BuildPipeline> adapters = List.of(
                new MakePipelineAdapter(new LegacyMakeTool()),
                new AntPipelineAdapter(new LegacyAntTool()));
        for (BuildPipeline p : adapters) {
            System.out.println("== " + p.getClass().getSimpleName());
            System.out.println("Returned value: " + p.run());
        }
    }
}
