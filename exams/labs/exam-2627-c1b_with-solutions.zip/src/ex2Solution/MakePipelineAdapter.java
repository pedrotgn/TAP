package ex2Solution;

/**
 * Object Adapter: the target is the abstract class BuildPipeline,
 * the adaptee is the third-party LegacyMakeTool (wrapped, not modified).
 */
public class MakePipelineAdapter extends BuildPipeline {

    private final LegacyMakeTool make;

    public MakePipelineAdapter(LegacyMakeTool make) {
        this.make = make;
    }

    @Override protected int compile()         { return step("compile", "make all", make.make("all")); }
    @Override protected int test()            { return step("test", "make check", make.make("check")); }
    @Override protected int packageArtifact() { return step("package", "make dist", make.make("dist")); }
}
