package ex2;

/**
 * Third-party class shipped as a binary library. DO NOT MODIFY THIS CLASS.
 * It is not a BuildPipeline and its API does not match ours.
 */
public class LegacyMakeTool {

    /**
     * Runs a make target and returns its duration in seconds.
     *
     * @param target one of "all", "check" or "dist"
     * @throws IllegalArgumentException for any other target
     */
    public int make(String target) {
        switch (target) {
            case "all":   return 50;
            case "check": return 80;
            case "dist":  return 10;
            default: throw new IllegalArgumentException("make: *** No rule to make target '" + target + "'");
        }
    }
}
