package ex2;

public class Main {

    public static void main(String[] args) {

        System.out.println("\n---------------- Exercise 2.1 ----------------");
        // TODO: run a MavenPipeline, a GradlePipeline and an NpmPipeline and print the total of each one

        System.out.println("\n---------------- Exercise 2.2 ----------------");
        // TODO: run a MakePipelineAdapter (wrapping a LegacyMakeTool) and an AntPipelineAdapter
        //       (wrapping a LegacyAntTool) and print the total of each one
    }
}
