package ex2;

/**
 * Base class of every build pipeline. Complete it (Task 2.1).
 */
public abstract class BuildPipeline {

}
