package ex1Solution;

import java.io.IOException;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.*;

/*
 * Expected results with issues.csv (seed 2026, 300 rows):
 *  1.1 auth(44) < backend(56) < database(48) < frontend(53) < mobile(51) < payments(48).
 *      Many ties: inside the same component ANY relative order is valid.
 *  1.2 10 distinct labels: bug, enhancement, performance, security, documentation, regression,
 *      accessibility, good-first-issue, duplicate, wontfix. ANY order is valid.
 *  1.3 "security" -> 43 issues (input order kept).
 *  1.4 6 groups: auth=44, backend=56, database=48, frontend=53, mobile=51, payments=48.
 *      Any Map implementation / key order is valid.
 *  1.5 "alice" -> Issue #1277 (2026-09-09 08:19:27). Unique answer: timestamps have no ties.
 *      "zoe"   -> Optional.empty
 */
public class Main {

    // 1.2
    static List<String> getDistinctLabels(List<Issue> issues) {
        return issues.stream()
                .flatMap(issue -> issue.getLabels().stream())
                .distinct()
                .collect(Collectors.toList());
    }

    // 1.3
    static List<Issue> filter(List<Issue> issues, Predicate<Issue> condition) {
        return issues.stream().filter(condition).collect(Collectors.toList());
    }

    static List<Issue> filterByLabel(List<Issue> issues, String label) {
        return filter(issues, issue -> issue.getLabels().contains(label));
    }

    // 1.4
    static Map<String, List<Issue>> groupByComponent(List<Issue> issues) {
        return issues.stream().collect(Collectors.groupingBy(Issue::getComponent));
    }

    // 1.5
    static Optional<Issue> getLatestIssueByReporter(List<Issue> issues, String reporter) {
        return issues.stream()
                .filter(issue -> issue.getReporter().equals(reporter))
                .max(Comparator.comparing(Issue::getCreated));
    }

    public static void main(String[] args) throws IOException {

        System.out.println("\n---------------- Dataset loading ----------------");
        List<Issue> issues = Issue.loadDataset("issues.csv");
        System.out.println(issues.size() + " issues loaded");

        System.out.println("\n---------------- Exercise 1.1 ----------------");
        List<Issue> sorted = new ArrayList<>(issues);
        sorted.sort(Comparator.comparing(Issue::getComponent));
        sorted.stream().limit(3).forEach(System.out::println);
        System.out.println("...");
        sorted.stream().skip(sorted.size() - 3).forEach(System.out::println);

        System.out.println("\n---------------- Exercise 1.2 ----------------");
        List<String> labels = getDistinctLabels(issues);
        System.out.println(labels.size() + " distinct labels: " + labels);

        System.out.println("\n---------------- Exercise 1.3 ----------------");
        List<Issue> security = filterByLabel(issues, "security");
        System.out.println(security.size() + " issues labelled 'security'");
        security.stream().limit(3).forEach(System.out::println);

        System.out.println("\n---------------- Exercise 1.4 ----------------");
        Map<String, List<Issue>> byComponent = groupByComponent(issues);
        new TreeMap<>(byComponent).forEach((c, list) -> System.out.println(c + " -> " + list.size() + " issues"));

        System.out.println("\n---------------- Exercise 1.5 ----------------");
        System.out.println("alice: " + getLatestIssueByReporter(issues, "alice"));
        System.out.println("zoe:   " + getLatestIssueByReporter(issues, "zoe"));
    }
}
