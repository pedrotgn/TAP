package ex1Solution;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Issue {
    private final int id;
    private final String reporter;
    private final String created;
    private final String title;
    private final String component;
    private final List<String> labels;

    public Issue(int id, String reporter, String created, String title, String component, List<String> labels) {
        this.id = id;
        this.reporter = reporter;
        this.created = created;
        this.title = title;
        this.component = component;
        this.labels = labels;
    }

    public int getId() { return id; }
    public String getReporter() { return reporter; }
    public String getCreated() { return created; }
    public String getTitle() { return title; }
    public String getComponent() { return component; }
    public List<String> getLabels() { return labels; }

    @Override
    public String toString() {
        return "Issue #" + id + " | Reporter=" + reporter + " | Created=" + created + " | Title=" + title
                + " | Component=" + component + " | Labels=" + labels;
    }

    /**
     * Loads the CSV file (first line is the header).
     * The Labels field is split by ';' into an unmodifiable list.
     */
    public static List<Issue> loadDataset(String filePath) throws IOException {
        List<Issue> issues = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line = reader.readLine(); // skip header
            while ((line = reader.readLine()) != null) {
                if (line.isBlank()) continue;
                String[] f = line.split(",");
                issues.add(new Issue(Integer.parseInt(f[0]), f[1], f[2], f[3], f[4], List.of(f[5].split(";"))));
            }
        }
        return issues;
    }
}
