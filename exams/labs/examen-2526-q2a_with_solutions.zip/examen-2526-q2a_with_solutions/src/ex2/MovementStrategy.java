package ex2;

public interface MovementStrategy {
    float calculateDuration(float distance);
}