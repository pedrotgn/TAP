package ex3;

public interface ProductInterface {
	
	String getName();
	
	float getPrice();

	void setName(String name);

	void setPrice(float price);
			
}