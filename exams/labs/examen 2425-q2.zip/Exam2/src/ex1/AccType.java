package ex1;

/**
 * Created by pedro on 9/21/15.
 */
public enum AccType {IF,CA,BA,SA};

