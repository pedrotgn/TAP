package ex2;

public class Main {

    public static void main(String[] args) {

        System.out.println("\n---------------- Exercise 2.1 ----------------");


    }
    
}
